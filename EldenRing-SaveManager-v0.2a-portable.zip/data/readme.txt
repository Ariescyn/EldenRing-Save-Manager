When drop trading with a friend:
  1. click file > save backup
  2. Go ingame, drop trade items to friend, exit game to main menu (or you can quit the game, up to you).
  3. click file > restore backup
  4. Done! Now your friend will have all of your items and you will still have all the items you gave him.


Creating save slots to easily store and load various builds before RESPEC, etc.
  
  - When creating a save slot, enter a name for the save and click 'Done'. It will then appear in the list box.
  - This will copy the contents of your appdata/roaming/EldenRing folder and back it up for easy retrieval.
  - Simply select the save slot you want to load into the game and click 'Load Save'.
  - To delete a save slot, select the slot and click 'Delete Save'.
  - Right-click on a save slot to edit notes. Notepad will open and allow you to enter details related to the save, like rune count, levels etc.